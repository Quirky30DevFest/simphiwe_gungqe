<?php
return json_decode( '{
	"77e88891e4965161953320ec66623cbc": {
		"name": "Greg Priday",
		"email": "77e88891e4965161953320ec66623cbc",
		"loc": 27653,
		"score": 1693.769725933136,
		"percent": 76.07556538398408
	},
	"85ce7a450a7ee4895f3bd823505e2e12": {
		"name": "adiraomj",
		"email": "85ce7a450a7ee4895f3bd823505e2e12",
		"loc": 3245,
		"score": 304.00205439896075,
		"percent": 13.654233991903691
	},
	"36639e6e074b731b093bde5a77305179": {
		"name": "Braam Genis",
		"email": "36639e6e074b731b093bde5a77305179",
		"loc": 3681,
		"score": 127.60282590870105,
		"percent": 5.731273252183361
	},
	"b7122312e4008f8f2c76911080bca01a": {
		"name": "Andrew Misplon",
		"email": "b7122312e4008f8f2c76911080bca01a",
		"loc": 986,
		"score": 97.75714686877707,
		"percent": 4.390756372900816
	},
	"a885c7bd5442dd2acd8c3e42001332c6": {
		"name": "Alex S",
		"email": "a885c7bd5442dd2acd8c3e42001332c6",
		"loc": 26,
		"score": 2.462522662838481,
		"percent": 0.11060405731546702
	},
	"07294cc1dd7658895e44c559dfffd76f": {
		"name": "gpriday",
		"email": "07294cc1dd7658895e44c559dfffd76f",
		"loc": 29,
		"score": 0.6523151634944362,
		"percent": 0.02929869634081786
	},
	"43c0e7220c23bd6636cf5469be6e9612": {
		"name": "Braam Genis",
		"email": "43c0e7220c23bd6636cf5469be6e9612",
		"loc": 7,
		"score": 0.1840867514634234,
		"percent": 0.008268245371764155
	}
}', true );